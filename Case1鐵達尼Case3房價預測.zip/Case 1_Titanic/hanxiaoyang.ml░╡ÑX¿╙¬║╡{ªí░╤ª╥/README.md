# Kaggle_Titanic
the data and ipython notebook of my attempt to solve the kaggle titanic problem

我自己实验Kaggle上的[Titanic问题](https://www.kaggle.com/c/titanic)的ipython notebook

train.csv和test.csv为使用到的的数据

对于**该问题的详细讲解**和**机器学习解决问题的一般思路**请戳[寒小阳的博客](http://blog.csdn.net/han_xiaoyang/article/details/49797143)

有任何问题欢迎联系hanxiaoyang.ml@gmail.com

